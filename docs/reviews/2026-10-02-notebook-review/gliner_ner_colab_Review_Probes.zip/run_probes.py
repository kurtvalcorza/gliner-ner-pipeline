"""Review probes for tutorials/gliner_ner_colab.ipynb (row 29, Notebook Review Framework v1).

Usage: python run_probes.py <worktree_root> <work_dir> [--no-exec]
Environment used by the reviewer: Windows 11 CPU, Python 3.12.14, torch 2.13.0+cpu (NOT the 2.14.0 pin),
transformers 4.57.6, gliner 0.2.29 (scratch venv layered on a read-only conda env). The install cell runs with
DIMER_NOTEBOOK_CI_PREINSTALLED=1, so pip is skipped; every other code cell runs unmodified, in order, in one
namespace, from an empty working directory, with no google.colab shim (USE_BYOD=False never imports it).
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import subprocess
import sys
import time
import types
from contextlib import redirect_stdout
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
NO_EXEC = '--no-exec' in sys.argv
NB = ROOT / 'tutorials' / 'gliner_ner_colab.ipynb'
OUT = Path(__file__).with_name('results.json')
results: dict = {}


def save():
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding='utf-8')


nb = json.loads(NB.read_text(encoding='utf-8'))
cells = nb['cells']
code_idx = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
src = {i: ''.join(c['source']) for i, c in enumerate(cells)}
md_all = '\n'.join(src[i] for i, c in enumerate(cells) if c['cell_type'] == 'markdown')

# ---------------- P1 static structure ----------------
p1 = {'nbformat': f"{nb['nbformat']}.{nb['nbformat_minor']}", 'n_cells': len(cells), 'n_code': len(code_idx),
      'metadata_dimer': nb['metadata'].get('dimer'), 'outputs_present': any(c.get('outputs') for c in cells if c['cell_type'] == 'code'),
      'compile_errors': []}
for i in code_idx:
    try:
        compile(src[i], f'cell{i}', 'exec')
    except SyntaxError as exc:
        p1['compile_errors'].append((i, str(exc)))
markers = {
    'how_to_use': 'How to use', 'roadmap': 'Roadmap', 'glossary': 'Glossary', 'predict': 'Predict',
    'what_to_notice': 'What to notice', 'expected_result': 'Expected result', 'check_reasoning': 'Check your',
    'troubleshooting': 'Troubleshooting', 'try_it': 'Try it', 'infrastructure_label': 'Infrastructure',
    'intended_learner': 'intended learner', 'conclusion_template': 'conclusion',
}
p1['guided_markers_in_markdown'] = {k: (v.lower() in md_all.lower()) for k, v in markers.items()}
p1['cellView_form_cells'] = [i for i in code_idx if cells[i].get('metadata', {}).get('cellView') == 'form']
p1['carried_module_chars'] = {i: len(src[i]) for i in code_idx if cells[i].get('metadata', {}).get('dimer', {}).get('embedded_module')}
p1['load_warnings_printed_in_notebook'] = any('load_warnings' in src[i] for i in code_idx if i not in p1['carried_module_chars'])
p1['form_fields'] = [l.strip() for i in code_idx for l in src[i].splitlines() if '# @param' in l]
p1['threshold_form_field_present'] = any('THRESHOLD' in f for f in p1['form_fields'])
p1['byod_location_field_present'] = any('PATH' in f.upper() for f in p1['form_fields'])
p1['byod_uses_google_colab_upload'] = 'files.upload()' in src[13]
p1['spec_declared'] = nb['metadata']['dimer'].get('notebook_spec')
p1['ci_env_var_documented_in_markdown'] = 'DIMER_NOTEBOOK_CI_PREINSTALLED' in md_all
p1['install_guard_raises_restart'] = 'Restart the runtime' in src[3]
p1['opening_claims'] = {
    'class_balance_preserved': 'class balance preserved' in md_all or 'class coverage preserved' in md_all,
    'verify_parameter_match': 'parameter match' in md_all,
    'byod_schema_stated_in_section4': ('"tokenized_text"' in src[12]) or ('tokenized_text' in src[12]),
}
results['P1_static'] = p1
save()

# ---------------- P2 generator / validator / unit tests ----------------
p2 = {}
for name, cmd in {
    'build_check': [sys.executable, 'tools/build_notebook.py', '--check'],
    'validate_release_assets': [sys.executable, 'tools/validate_release_assets.py'],
}.items():
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    p2[name] = {'rc': r.returncode, 'tail': (r.stdout + r.stderr)[-600:]}
results['P2_generator'] = p2
save()

# ---------------- namespace with carried modules (no model) ----------------
ns: dict = {'__name__': '__main__'}
for i in (5, 7, 9):
    exec(compile(src[i], f'cell{i}', 'exec'), ns)

# ---------------- P3 split / leakage analysis ----------------
ds = ns['generate_synthetic_ner_dataset']()
train, val = ns['split_ner_dataset'](ds, val_fraction=0.25, seed=42)


def ents(rs):
    return {(s['text'].lower(), s['label']) for r in rs for s in r['spans']}


tr_e, va_e = ents(train), ents(val)
test_sentence = 'Pembrolizumab blocks PDCD1 receptor to treat metastatic melanoma in adult patients.'
p3 = {
    'n_train': len(train), 'n_val': len(val), 'val_ids': [r['id'] for r in val],
    'val_label_coverage': sorted({s['label'] for r in val for s in r['spans']}),
    'val_entities': len(va_e), 'val_entities_also_in_train': sorted(va_e & tr_e),
    'frac_val_entities_seen_in_train': round(len(va_e & tr_e) / max(1, len(va_e)), 4),
    'bio005_text': next(r['text'] for r in ds if r['id'] == 'bio-005'),
    'bio005_in_train': any(r['id'] == 'bio-005' for r in train),
    'test_sentence': test_sentence,
    'test_entity_strings_in_train': [w for w in ('Pembrolizumab', 'PDCD1', 'metastatic melanoma') if any(w.lower() == s['text'].lower() for r in train for s in r['spans'])],
    'sentence_template_first_token_is_drug': sum(1 for r in ds if r['ner'] and r['ner'][0][:2] == [0, 0] and r['ner'][0][2] == 'chemical_drug'),
    'n_records': len(ds),
}
# split coverage guarantee: does the split enforce class coverage? try a dataset where one label is rare
rare = [dict(r) for r in ds]
cov_fail = []
for seed in range(200):
    t, v = ns['split_ner_dataset'](rare, val_fraction=0.25, seed=seed)
    labs = {s[2] for r in v for s in r['ner']}
    if labs != set(ns['ADAPT_CLASSES']):
        cov_fail.append(seed)
p3['seeds_0_199_val_missing_a_class'] = len(cov_fail)
# small dataset: 4 records, val_fraction .25 -> 1 val record
small = ds[:4]
t, v = ns['split_ner_dataset'](small, val_fraction=0.25, seed=42)
try:
    ns['validate_dataset'](v)
    p3['min_dataset_val_split_valid'] = True
except Exception as exc:  # noqa: BLE001
    p3['min_dataset_val_split_valid'] = f'{type(exc).__name__}: {exc}'
small2 = [ds[9], ds[13], ds[0], ds[1], ds[2], ds[3]]  # val may lack gene_protein
fails = 0
for seed in range(50):
    t, v = ns['split_ner_dataset'](small2, val_fraction=0.25, seed=seed)
    try:
        ns['validate_dataset'](v); ns['validate_dataset'](t)
    except Exception:  # noqa: BLE001
        fails += 1
p3['six_record_byod_split_validation_failures_of_50_seeds'] = fails
results['P3_split'] = p3
save()

# ---------------- P4 BYOD contract ----------------
byod = WORK / 'byod_probe'
byod.mkdir(parents=True, exist_ok=True)
p4 = {}


def try_load(name, payload, labels=None):
    path = byod / name
    path.write_text(payload, encoding='utf-8')
    try:
        recs = ns['load_byod_dataset'](path) if labels is None else ns['load_byod_dataset'](path, labels)
        return f'accepted ({len(recs)} records)'
    except Exception as exc:  # noqa: BLE001
        return f'{type(exc).__name__}: {exc}'


sample_jsonl = '\n'.join(json.dumps({'id': r['id'], 'tokenized_text': r['tokenized_text'], 'ner': r['ner']}) for r in ds)
p4['sample_roundtrip_jsonl'] = try_load('ok.jsonl', sample_jsonl)
p4['tokens_alias_json'] = try_load('ok.json', json.dumps([{'id': r['id'], 'tokens': r['tokenized_text'], 'ner': r['ner']} for r in ds]))
generic = [{'id': f'g{i}', 'tokenized_text': ['Maria', 'Santos', 'works', 'at', 'DOST', 'in', 'Manila', '.'],
            'ner': [[0, 1, 'person'], [4, 4, 'organization'], [6, 6, 'location']]} for i in range(8)]
p4['generic_person_org_location_labels'] = try_load('generic.jsonl', '\n'.join(json.dumps(g) for g in generic))
two_label = [{'id': r['id'], 'tokenized_text': r['tokenized_text'], 'ner': [s for s in r['ner'] if s[2] != 'gene_protein']} for r in ds]
p4['subset_two_of_three_labels'] = try_load('two.jsonl', '\n'.join(json.dumps(g) for g in two_label))
p4['bad_json'] = try_load('bad.json', '{not json')
p4['csv_file'] = try_load('data.csv', 'id,text\n1,hello')
p4['ner_as_dict'] = try_load('dict.jsonl', json.dumps({'id': 'x', 'tokenized_text': ['a'], 'ner': [{'start': 0, 'end': 0, 'label': 'disease'}]}))
p4['label_parameterisable_from_notebook'] = 'allowed_labels' in src[13] or 'LABELS' in src[13]
# cancelled upload
try:
    next(iter({}.items()))
except StopIteration as exc:
    p4['cancelled_upload_error'] = f'StopIteration{exc.args}'
results['P4_byod'] = p4
save()

if NO_EXEC:
    sys.exit(0)

# ---------------- P5 default path, all code cells ----------------
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ['HF_HOME'] = str(WORK / 'hf_home')
# No google.colab shim: the default path (USE_BYOD=False) never imports it, and a bare shim module without
# __spec__ breaks transformers' importlib.util.find_spec probing (observed in attempt 1).
run_dir = WORK / 'run'
run_dir.mkdir(parents=True, exist_ok=True)
os.chdir(run_dir)
ns2: dict = {'__name__': '__main__'}
p5 = {'cells': []}
results['P5_default'] = p5
for i in code_idx:
    buf = io.StringIO(); t0 = time.perf_counter(); err = None
    try:
        with redirect_stdout(buf):
            exec(compile(src[i], f'cell{i}', 'exec'), ns2)
    except Exception as exc:  # noqa: BLE001
        err = f'{type(exc).__name__}: {exc}'
    p5['cells'].append({'cell': i, 'seconds': round(time.perf_counter() - t0, 1), 'error': err, 'stdout_tail': buf.getvalue()[-1500:]})
    save()
    if err:
        break
p5['completed'] = all(c['error'] is None for c in p5['cells']) and len(p5['cells']) == len(code_idx)
p5['total_seconds'] = round(sum(c['seconds'] for c in p5['cells']), 1)
if p5['completed']:
    be, ae = ns2['baseline_eval'], ns2['adapted_eval']
    p5['baseline_micro'] = be['micro']; p5['adapted_micro'] = ae['micro']
    p5['baseline_macro_f1'] = be['macro']['f1']; p5['adapted_macro_f1'] = ae['macro']['f1']
    p5['delta'] = ns2['eval_report']['delta']; p5['history'] = ns2['adapt_result']['history']
    p5['val_records'] = be['num_samples']
    p5['inference_entities'] = ns2['entities']
    p5['load_warnings'] = ns2['pipe'].load_warnings
    model = ns2['pipe'].model
    trainable = [(n, p.numel()) for n, p in model.named_parameters() if p.requires_grad]
    frozen = sum(p.numel() for p in model.parameters() if not p.requires_grad)
    p5['trainable_params'] = sum(n for _, n in trainable); p5['frozen_params'] = frozen
    p5['trainable_top_modules'] = sorted({n.split('.')[1] if n.startswith('model.') else n.split('.')[0] for n, _ in trainable})
    p5['artifact_bytes'] = (run_dir / 'outputs' / 'gliner_ner_adapter.pt').stat().st_size
    p5['outputs'] = sorted(os.listdir(run_dir / 'outputs'))
save()

# ---------------- P6 rerun semantics (active learning / BYOD rerun scope) ----------------
if p5.get('completed'):
    p6 = {}
    pipe = ns2['pipe']
    rerun_baseline = pipe.evaluate(ns2['val_records'], labels=ns2['ADAPT_CLASSES'])
    p6['section5_rerun_after_adaptation_micro'] = rerun_baseline['micro']
    p6['section5_rerun_equals_adapted'] = rerun_baseline['micro'] == ns2['adapted_eval']['micro']
    p6['original_baseline_micro'] = ns2['baseline_eval']['micro']
    # Re-run Section 6 (EPOCHS=3 again) as a learner changing nothing: does training continue from adapted weights?
    w_before = {n: p.detach().clone() for n, p in pipe.model.named_parameters() if p.requires_grad}
    r2 = pipe.adapt(ns2['train_records'], ns2['val_records'], epochs=3, learning_rate=5e-5, batch_size=4, freeze_text_encoder=True, seed=42)
    p6['second_adapt_history'] = r2['history']
    p6['second_adapt_starts_from_adapted_weights'] = r2['history'][0]['loss'] < ns2['adapt_result']['history'][0]['loss']
    p6['first_adapt_epoch1_loss'] = ns2['adapt_result']['history'][0]['loss']
    p6['weights_changed_by_second_adapt'] = any(not (w_before[n] == p).all().item() for n, p in pipe.model.named_parameters() if p.requires_grad)
    results['P6_rerun'] = p6
    save()

# ---------------- P7 artifact reload robustness ----------------
if p5.get('completed'):
    import torch
    p7 = {}; results['P7_reload'] = p7
    art = run_dir / 'outputs' / 'gliner_ner_adapter.pt'
    payload = torch.load(art, map_location='cpu', weights_only=True)
    p7['payload_keys'] = sorted(payload)
    p7['adapter_tensors'] = len(payload['adapter_state_dict'])
    p7['artifact_sha256'] = hashlib.sha256(art.read_bytes()).hexdigest()
    empty = dict(payload); empty['adapter_state_dict'] = {}
    torch.save(empty, run_dir / 'empty_adapter.pt')
    wrongrev = dict(payload); wrongrev['base_model'] = dict(payload['base_model'], model_revision='0' * 40)
    torch.save(wrongrev, run_dir / 'wrongrev_adapter.pt')
    renamed = dict(payload); renamed['adapter_state_dict'] = {'x.' + k: v for k, v in payload['adapter_state_dict'].items()}
    torch.save(renamed, run_dir / 'renamed_adapter.pt')
    G = ns2['GLiNERPipeline']
    ts = ns2['test_sentence']
    for name in ('empty_adapter.pt', 'wrongrev_adapter.pt', 'renamed_adapter.pt'):
        try:
            rp = G.from_artifact(run_dir / name, weights_dir=ns2['WEIGHTS_DIR'], encoder_dir=ns2['ENCODER_WEIGHTS_DIR'])
            ents_ = rp.detect(ts, labels=ns2['ADAPT_CLASSES'])['entities']
            same = [(e['start'], e['end'], e['label']) for e in ents_] == [(e['start'], e['end'], e['label']) for e in ns2['entities']]
            p7[name] = {'loaded': True, 'entities': [(e['text'], e['label'], round(e['score'], 4)) for e in ents_], 'spans_labels_match_adapted': same}
            del rp
        except Exception as exc:  # noqa: BLE001
            p7[name] = {'loaded': False, 'error': f'{type(exc).__name__}: {exc}'}
        save()
    results['P7_reload'] = p7
    save()
print('done')
